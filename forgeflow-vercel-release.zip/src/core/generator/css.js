/**
 * styles.css generator. Theme tokens are derived from spec.theme.
 */

function hexToRgb(hex) {
  const m = /^#([0-9a-f]{6})$/i.exec(String(hex || '').trim());
  const int = m ? parseInt(m[1], 16) : 0x4f6bed;
  return [(int >> 16) & 255, (int >> 8) & 255, int & 255];
}

export function generateCss(spec) {
  const [r, g, b] = hexToRgb(spec.theme.accent);
  const dark = spec.theme.mode === 'dark';
  const compact = spec.theme.density === 'compact';

  const tokens = dark
    ? {
        bg: '#12151c',
        panel: '#1a1f29',
        panelAlt: '#212837',
        text: '#e8ecf4',
        muted: '#9aa4b8',
        border: '#2b3345',
        shadow: '0 8px 24px rgba(0,0,0,.35)',
      }
    : {
        bg: '#f5f7fb',
        panel: '#ffffff',
        panelAlt: '#f0f3f9',
        text: '#1d2333',
        muted: '#68708a',
        border: '#e1e6f0',
        shadow: '0 6px 20px rgba(24,35,68,.08)',
      };

  return `/* ForgeFlow deterministic demo snapshot — theme: ${spec.theme.mode} */
:root {
  --accent: ${spec.theme.accent};
  --accent-rgb: ${r}, ${g}, ${b};
  --accent-soft: rgba(${r}, ${g}, ${b}, ${dark ? 0.22 : 0.12});
  --bg: ${tokens.bg};
  --panel: ${tokens.panel};
  --panel-alt: ${tokens.panelAlt};
  --text: ${tokens.text};
  --muted: ${tokens.muted};
  --border: ${tokens.border};
  --shadow: ${tokens.shadow};
  --radius: 12px;
  --gap: ${compact ? '10px' : '16px'};
  --danger: #d64545;
  --ok: #1f9d6b;
}

* { box-sizing: border-box; }

/* hidden 全局兜底：UA 默认的 hidden 规则特异性只有 (0,1,0)，会被
   .overlay / .stats / .filters 这些显式声明 display 的类规则压掉，导致
   node.hidden = true 之后 computed display 仍是 flex/grid。 */
[hidden] { display: none !important; }

body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font: 14px/1.6 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}

.app-shell { max-width: 960px; margin: 0 auto; padding: 20px 16px 48px; }

.app-header {
  display: flex; flex-wrap: wrap; gap: 12px;
  align-items: flex-end; justify-content: space-between;
  padding-bottom: 14px; border-bottom: 1px solid var(--border); margin-bottom: var(--gap);
}
.app-title h1 { margin: 0; font-size: 20px; letter-spacing: .2px; }
.tagline { margin: 4px 0 0; color: var(--muted); font-size: 13px; }
.header-actions { display: flex; gap: 8px; }

.btn {
  border: 1px solid var(--border); background: var(--panel); color: var(--text);
  border-radius: 8px; padding: 7px 14px; font-size: 13px; cursor: pointer;
  transition: transform .06s ease, background .15s ease, border-color .15s ease;
}
.btn:hover { border-color: var(--accent); }
.btn:active { transform: translateY(1px); }
.btn.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
.btn.ghost { background: transparent; }
.btn.link { background: none; border: none; color: var(--muted); text-decoration: underline; padding: 4px; }
.btn.tiny { padding: 3px 9px; font-size: 12px; }
.btn.danger { color: var(--danger); }

.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: var(--gap); }
.stat {
  background: var(--panel); border: 1px solid var(--border); border-radius: var(--radius);
  padding: 12px 14px; box-shadow: var(--shadow);
}
.stat .stat-label { color: var(--muted); font-size: 12px; }
.stat .stat-value { font-size: 22px; font-weight: 650; margin-top: 2px; }
.stat .stat-bar { height: 4px; border-radius: 4px; background: var(--panel-alt); margin-top: 8px; overflow: hidden; }
.stat .stat-bar > span { display: block; height: 100%; background: var(--accent); }

.toolbar { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-bottom: var(--gap); }
.search-box { flex: 1 1 220px; min-width: 180px; }
.filters { display: flex; flex-wrap: wrap; gap: 8px; }
.count { color: var(--muted); font-size: 12px; margin-left: auto; }

input, select, textarea {
  width: 100%; padding: 8px 10px; font: inherit; color: var(--text);
  background: var(--panel); border: 1px solid var(--border); border-radius: 8px;
}
input:focus, select:focus, textarea:focus { outline: 2px solid var(--accent-soft); border-color: var(--accent); }
textarea { min-height: 72px; resize: vertical; }
.filters select { width: auto; min-width: 120px; }

.list { display: grid; gap: 10px; }
.list.view-cards { grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); }
.list.view-list { grid-template-columns: 1fr; }
.list.view-table { display: block; overflow-x: auto; }

.card {
  background: var(--panel); border: 1px solid var(--border); border-left: 3px solid var(--accent);
  border-radius: var(--radius); padding: 12px 14px; box-shadow: var(--shadow);
  display: flex; flex-direction: column; gap: 8px;
}
.card-head { display: flex; justify-content: space-between; gap: 8px; align-items: flex-start; }
.card-title { font-weight: 600; font-size: 15px; word-break: break-word; }
.card-meta { display: flex; flex-wrap: wrap; gap: 6px; }
.tag {
  font-size: 12px; padding: 2px 8px; border-radius: 999px;
  background: var(--accent-soft); color: var(--accent); white-space: nowrap;
}
.tag.plain { background: var(--panel-alt); color: var(--muted); }
.tag.done { background: rgba(31,157,107,.16); color: var(--ok); }
.tag.high { background: rgba(214,69,69,.16); color: var(--danger); }
.card-notes { color: var(--muted); font-size: 13px; white-space: pre-wrap; word-break: break-word; }
.card-actions { display: flex; gap: 6px; justify-content: flex-end; }

table.data-table { width: 100%; border-collapse: collapse; background: var(--panel); border-radius: var(--radius); overflow: hidden; }
table.data-table th, table.data-table td { padding: 9px 12px; text-align: left; border-bottom: 1px solid var(--border); font-size: 13px; white-space: nowrap; }
table.data-table th { background: var(--panel-alt); color: var(--muted); font-weight: 600; }
table.data-table tr:last-child td { border-bottom: none; }

.empty { text-align: center; color: var(--muted); padding: 28px 12px; border: 1px dashed var(--border); border-radius: var(--radius); }

.app-footer { margin-top: 24px; display: flex; justify-content: space-between; align-items: center; gap: 8px; color: var(--muted); font-size: 12px; flex-wrap: wrap; }

.overlay { position: fixed; inset: 0; background: rgba(8, 12, 22, .5); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 40; }
.modal { background: var(--panel); border-radius: 14px; border: 1px solid var(--border); width: min(520px, 100%); max-height: 88vh; overflow: auto; padding: 18px; box-shadow: 0 20px 48px rgba(0,0,0,.25); }
.modal h2 { margin: 0 0 12px; font-size: 16px; }
.form-fields { display: grid; gap: 10px; }
.form-row label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 4px; }
.form-row.checkbox { display: flex; align-items: center; gap: 8px; }
.form-row.checkbox input { width: auto; }
.form-row .req { color: var(--danger); margin-left: 2px; }
.form-error { color: var(--danger); font-size: 13px; margin: 10px 0 0; }
.modal-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px; }

.toast {
  position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%);
  background: var(--text); color: var(--bg); padding: 8px 16px; border-radius: 999px;
  font-size: 13px; z-index: 60; box-shadow: var(--shadow);
}

@media (max-width: 640px) {
  .app-shell { padding: 14px 12px 40px; }
  .app-header { align-items: flex-start; }
  .header-actions { width: 100%; }
  .header-actions .btn { flex: 1; }
  .count { margin-left: 0; }
  .list.view-cards { grid-template-columns: 1fr; }
  .modal { padding: 14px; }
}
`;
}
