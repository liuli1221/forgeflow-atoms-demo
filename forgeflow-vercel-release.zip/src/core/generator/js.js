/**
 * app.js generator.
 *
 * The emitted runtime builds every DOM node with createElement/textContent, so
 * business data and prompt-derived labels can never become executable markup.
 * The AppSpec is injected as JSON data (toSafeJson), never spliced as source.
 *
 * Persistence: when the app runs inside the ForgeFlow preview iframe it talks
 * to the host through postMessage (the sandbox has no same-origin storage);
 * when opened standalone it falls back to its own localStorage. Either way the
 * data survives a refresh.
 */
import { toSafeJson } from '../util.js';
import { getBlueprint } from '../blueprints.js';

export function generateJs(spec) {
  const done = getBlueprint(spec.domain).doneField;
  const doneJson = toSafeJson(done && spec.fields.some((f) => f.key === done.field) ? done : null);

  return `/* ForgeFlow deterministic demo snapshot. No external dependency. */
const SPEC = ${toSafeJson(spec)};
const DONE = ${doneJson};
const STORAGE_KEY = 'forgeflow.appdata.' + SPEC.appId;

const embedded = (function () {
  try { return !!window.parent && window.parent !== window; } catch (e) { return false; }
})();

const state = {
  items: [],
  query: '',
  filters: {},
  view: SPEC.layout.view,
  editingId: null,
  pendingDelete: null,
  booted: false
};

/* ---------------------------------------------------------------- utils */
function el(tag, attrs, children) {
  const node = document.createElement(tag);
  if (attrs) {
    Object.keys(attrs).forEach(function (k) {
      const v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = String(v);
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : String(v));
    });
  }
  if (children) {
    [].concat(children).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
    });
  }
  return node;
}

function makeId() {
  return 'it_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function report(level, message) {
  if (!embedded) return;
  try {
    window.parent.postMessage({
      source: 'forgeflow-app', type: 'log', level: level,
      message: String(message), appId: SPEC.appId, at: Date.now()
    }, '*');
  } catch (e) { /* ignore */ }
}

window.addEventListener('error', function (ev) {
  report('error', 'runtime error: ' + (ev && ev.message ? ev.message : 'unknown'));
});

/* ------------------------------------------------------------ persistence */
function defaultFor(field) {
  if (field.default !== undefined) return field.default;
  if (field.type === 'checkbox') return false;
  if (field.type === 'number') return 0;
  return '';
}

function normalize(raw) {
  const item = { id: raw && raw.id ? String(raw.id) : makeId() };
  SPEC.fields.forEach(function (f) {
    let v = raw ? raw[f.key] : undefined;
    if (v === undefined || v === null) v = defaultFor(f);
    if (f.type === 'checkbox') v = !!v;
    else if (f.type === 'number') v = num(v);
    else v = String(v);
    if (f.type === 'select' && f.options.indexOf(v) === -1) v = f.options.indexOf(f.default) >= 0 ? f.default : f.options[0];
    item[f.key] = v;
  });
  item.createdAt = raw && raw.createdAt ? raw.createdAt : new Date().toISOString();
  return item;
}

function persist() {
  const payload = { appId: SPEC.appId, items: state.items, savedAt: new Date().toISOString() };
  if (embedded) {
    try {
      window.parent.postMessage({ source: 'forgeflow-app', type: 'save', key: STORAGE_KEY, data: payload }, '*');
    } catch (e) { report('error', 'save failed: ' + e.message); }
  } else {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload)); }
    catch (e) { report('error', 'localStorage save failed: ' + e.message); }
  }
}

function readStandalone() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

function seed() {
  return SPEC.seedItems.map(normalize);
}

function boot(data) {
  if (state.booted) return;
  state.booted = true;
  const items = data && Array.isArray(data.items) ? data.items : null;
  state.items = items && items.length ? items.map(normalize) : seed();
  mount();
  render();
  report('info', 'app ready with ' + state.items.length + ' items');
}

/* ------------------------------------------------------------- filtering */
function textFields() {
  return SPEC.fields.filter(function (f) { return f.type === 'text' || f.type === 'textarea'; });
}

function matchesQuery(item) {
  if (!state.query) return true;
  const q = state.query.toLowerCase();
  return textFields().some(function (f) { return String(item[f.key] || '').toLowerCase().indexOf(q) !== -1; });
}

function matchesFilters(item) {
  return SPEC.filters.every(function (flt) {
    const picked = state.filters[flt.field];
    if (!picked) return true;
    return String(item[flt.field]) === picked;
  });
}

function visibleItems() {
  return state.items.filter(function (i) { return matchesQuery(i) && matchesFilters(i); });
}

/* --------------------------------------------------------------- metrics */
function whereMatch(item, where) {
  if (!where) return true;
  return String(item[where.field]) === String(where.value);
}

function computeMetric(m, items) {
  if (m.type === 'count') return items.filter(function (i) { return whereMatch(i, m.where); }).length;
  if (m.type === 'sum') {
    return items.filter(function (i) { return whereMatch(i, m.where); })
      .reduce(function (a, i) { return a + num(i[m.field]); }, 0);
  }
  if (m.type === 'avg') {
    const list = items.filter(function (i) { return whereMatch(i, m.where); });
    if (!list.length) return 0;
    return list.reduce(function (a, i) { return a + num(i[m.field]); }, 0) / list.length;
  }
  if (m.type === 'percent') {
    if (!items.length) return 0;
    return (items.filter(function (i) { return whereMatch(i, m.where); }).length / items.length) * 100;
  }
  if (m.type === 'delta') {
    const plus = items.filter(function (i) { return whereMatch(i, m.plusWhere); })
      .reduce(function (a, i) { return a + num(i[m.field]); }, 0);
    const minus = items.filter(function (i) { return whereMatch(i, m.minusWhere); })
      .reduce(function (a, i) { return a + num(i[m.field]); }, 0);
    return plus - minus;
  }
  return 0;
}

function formatMetric(value, format) {
  if (format === 'percent') return Math.round(value) + '%';
  if (format === 'currency') return '¥' + (Math.round(value * 100) / 100).toLocaleString('zh-CN');
  return Number.isInteger(value) ? String(value) : String(Math.round(value * 10) / 10);
}

/* ----------------------------------------------------------------- views */
const dom = {};

function mount() {
  dom.stats = document.getElementById('stats');
  dom.filters = document.getElementById('filters');
  dom.list = document.getElementById('list');
  dom.empty = document.getElementById('empty');
  dom.search = document.getElementById('search');
  dom.count = document.getElementById('result-count');
  dom.overlay = document.getElementById('overlay');
  dom.form = document.getElementById('item-form');
  dom.formFields = document.getElementById('form-fields');
  dom.formError = document.getElementById('form-error');
  dom.modalTitle = document.getElementById('modal-title');
  dom.toast = document.getElementById('toast');

  document.getElementById('add-btn').addEventListener('click', function () { openForm(null); });
  document.getElementById('cancel-btn').addEventListener('click', closeForm);
  document.getElementById('view-toggle').addEventListener('click', cycleView);
  document.getElementById('reset-btn').addEventListener('click', resetData);
  dom.form.addEventListener('submit', submitForm);
  dom.overlay.addEventListener('click', function (ev) { if (ev.target === dom.overlay) closeForm(); });
  if (dom.search) {
    dom.search.addEventListener('input', function (ev) {
      state.query = ev.target.value.trim();
      renderList();
    });
  }
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') closeForm(); });
}

function toast(message) {
  if (!dom.toast) return;
  dom.toast.textContent = message;
  dom.toast.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(function () { dom.toast.hidden = true; }, 1800);
}

function render() {
  renderStats();
  renderFilters();
  renderList();
}

function renderStats() {
  if (!SPEC.layout.showStats || !dom.stats) return;
  dom.stats.textContent = '';
  SPEC.metrics.forEach(function (m) {
    const value = computeMetric(m, state.items);
    const card = el('div', { class: 'stat' }, [
      el('div', { class: 'stat-label', text: m.label }),
      el('div', { class: 'stat-value', text: formatMetric(value, m.format) })
    ]);
    if (m.format === 'percent') {
      const bar = el('div', { class: 'stat-bar' }, [el('span')]);
      bar.firstChild.style.width = Math.max(0, Math.min(100, value)) + '%';
      card.appendChild(bar);
    }
    dom.stats.appendChild(card);
  });
}

function renderFilters() {
  if (!SPEC.layout.showFilters || !dom.filters) return;
  dom.filters.textContent = '';
  SPEC.filters.forEach(function (flt) {
    const field = SPEC.fields.filter(function (f) { return f.key === flt.field; })[0];
    if (!field) return;
    const select = el('select', { 'aria-label': flt.label });
    select.appendChild(el('option', { value: '', text: '全部' + flt.label }));
    field.options.forEach(function (opt) {
      select.appendChild(el('option', { value: opt, text: opt, selected: state.filters[flt.field] === opt }));
    });
    select.addEventListener('change', function (ev) {
      state.filters[flt.field] = ev.target.value;
      renderList();
    });
    dom.filters.appendChild(select);
  });
}

function badge(field, value) {
  let cls = 'tag plain';
  if (field.key === 'priority' && value === '高') cls = 'tag high';
  else if (DONE && field.key === DONE.field && String(value) === String(DONE.value)) cls = 'tag done';
  else if (field.key === 'category' || field.key === 'type' || field.key === 'sentiment') cls = 'tag';
  return el('span', { class: cls, text: field.label + '：' + value });
}

function renderCard(item) {
  const primary = SPEC.fields.filter(function (f) { return f.primary; })[0] || SPEC.fields[0];
  const notesField = SPEC.fields.filter(function (f) { return f.type === 'textarea'; })[0];
  const metaFields = SPEC.fields.filter(function (f) {
    return f !== primary && f.type !== 'textarea';
  });

  const meta = el('div', { class: 'card-meta' });
  metaFields.forEach(function (f) {
    const v = item[f.key];
    if (f.type === 'checkbox') { meta.appendChild(badge(f, v ? '是' : '否')); return; }
    if (v === '' || v === null || v === undefined) return;
    meta.appendChild(badge(f, v));
  });

  const actions = el('div', { class: 'card-actions' }, [
    DONE ? el('button', {
      class: 'btn tiny', type: 'button',
      text: isDone(item) ? '撤销完成' : '标记完成',
      onclick: function () { toggleDone(item.id); }
    }) : null,
    el('button', { class: 'btn tiny', type: 'button', text: '编辑', onclick: function () { openForm(item.id); } }),
    el('button', {
      class: 'btn tiny danger', type: 'button',
      text: state.pendingDelete === item.id ? '确认删除' : '删除',
      onclick: function () { requestDelete(item.id); }
    })
  ]);

  return el('div', { class: 'card' }, [
    el('div', { class: 'card-head' }, [el('div', { class: 'card-title', text: item[primary.key] || '(未命名)' })]),
    meta,
    notesField && item[notesField.key] ? el('div', { class: 'card-notes', text: item[notesField.key] }) : null,
    actions
  ]);
}

function renderTable(items) {
  const cols = SPEC.fields.filter(function (f) { return f.type !== 'textarea'; });
  const head = el('tr', null, cols.map(function (f) { return el('th', { text: f.label }); }).concat([el('th', { text: '操作' })]));
  const rows = items.map(function (item) {
    const tds = cols.map(function (f) {
      const v = f.type === 'checkbox' ? (item[f.key] ? '是' : '否') : item[f.key];
      return el('td', { text: v === '' || v === undefined || v === null ? '-' : String(v) });
    });
    tds.push(el('td', null, [
      el('button', { class: 'btn tiny', type: 'button', text: '编辑', onclick: function () { openForm(item.id); } }),
      el('button', {
        class: 'btn tiny danger', type: 'button',
        text: state.pendingDelete === item.id ? '确认删除' : '删除',
        onclick: function () { requestDelete(item.id); }
      })
    ]));
    return el('tr', null, tds);
  });
  return el('table', { class: 'data-table' }, [el('thead', null, [head]), el('tbody', null, rows)]);
}

function renderList() {
  if (!dom.list) return;
  const items = visibleItems();
  dom.list.textContent = '';
  dom.list.className = 'list view-' + state.view;

  if (dom.count) {
    dom.count.textContent = '共 ' + items.length + ' 条' + (items.length !== state.items.length ? '（总 ' + state.items.length + '）' : '');
  }

  if (!items.length) {
    dom.empty.hidden = false;
    dom.empty.textContent = state.items.length
      ? '没有符合条件的' + SPEC.entityName + '，试试清空搜索或筛选。'
      : '还没有任何' + SPEC.entityName + '，点右上角「新增」开始记录。';
    return;
  }
  dom.empty.hidden = true;

  if (state.view === 'table') {
    dom.list.appendChild(renderTable(items));
  } else {
    items.forEach(function (item) { dom.list.appendChild(renderCard(item)); });
  }
}

function cycleView() {
  const order = ['cards', 'table', 'list'];
  state.view = order[(order.indexOf(state.view) + 1) % order.length];
  renderList();
  toast('视图：' + state.view);
}

/* ------------------------------------------------------------------ CRUD */
function isDone(item) {
  if (!DONE) return false;
  return String(item[DONE.field]) === String(DONE.value);
}

function toggleDone(id) {
  const item = state.items.filter(function (i) { return i.id === id; })[0];
  if (!item || !DONE) return;
  const field = SPEC.fields.filter(function (f) { return f.key === DONE.field; })[0];
  if (!field) return;
  if (field.type === 'checkbox') item[field.key] = !item[field.key];
  else item[field.key] = isDone(item) ? (field.options[0] || field.default) : DONE.value;
  persist();
  render();
  report('info', 'toggle done: ' + id);
}

function requestDelete(id) {
  if (state.pendingDelete !== id) {
    state.pendingDelete = id;
    renderList();
    toast('再点一次「确认删除」即可删除');
    clearTimeout(requestDelete._t);
    requestDelete._t = setTimeout(function () { state.pendingDelete = null; renderList(); }, 4000);
    return;
  }
  state.items = state.items.filter(function (i) { return i.id !== id; });
  state.pendingDelete = null;
  persist();
  render();
  toast('已删除');
  report('info', 'delete item ' + id);
}

function resetData() {
  state.items = seed();
  persist();
  render();
  toast('已重置为示例数据');
}

function openForm(id) {
  state.editingId = id;
  const item = id ? state.items.filter(function (i) { return i.id === id; })[0] : null;
  dom.modalTitle.textContent = (id ? '编辑' : '新增') + SPEC.entityName;
  dom.formError.hidden = true;
  dom.formFields.textContent = '';

  SPEC.fields.forEach(function (f) {
    const value = item ? item[f.key] : defaultFor(f);
    const inputId = 'fld_' + f.key;
    let input;
    if (f.type === 'textarea') {
      input = el('textarea', { id: inputId, name: f.key, placeholder: f.placeholder || '' });
      input.value = String(value || '');
    } else if (f.type === 'select') {
      input = el('select', { id: inputId, name: f.key });
      f.options.forEach(function (opt) {
        input.appendChild(el('option', { value: opt, text: opt, selected: String(value) === opt }));
      });
    } else if (f.type === 'checkbox') {
      input = el('input', { id: inputId, name: f.key, type: 'checkbox' });
      input.checked = !!value;
    } else {
      input = el('input', {
        id: inputId, name: f.key,
        type: f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text',
        placeholder: f.placeholder || ''
      });
      input.value = value === undefined || value === null ? '' : String(value);
    }

    const label = el('label', { for: inputId }, [f.label, f.required ? el('span', { class: 'req', text: '*' }) : null]);
    dom.formFields.appendChild(
      f.type === 'checkbox'
        ? el('div', { class: 'form-row checkbox' }, [input, label])
        : el('div', { class: 'form-row' }, [label, input])
    );
  });

  dom.overlay.hidden = false;
  const first = dom.formFields.querySelector('input, select, textarea');
  if (first) first.focus();
}

function closeForm() {
  dom.overlay.hidden = true;
  state.editingId = null;
}

function readForm() {
  const draft = {};
  const errors = [];
  SPEC.fields.forEach(function (f) {
    const node = document.getElementById('fld_' + f.key);
    if (!node) return;
    let v;
    if (f.type === 'checkbox') v = node.checked;
    else if (f.type === 'number') {
      const raw = node.value.trim();
      if (raw === '') v = f.required ? NaN : defaultFor(f);
      else v = Number(raw);
      if (!Number.isFinite(v)) errors.push(f.label + ' 必须是数字');
    } else v = node.value.trim();

    if (f.required && (v === '' || v === undefined || (typeof v === 'number' && !Number.isFinite(v)))) {
      errors.push(f.label + ' 不能为空');
    }
    draft[f.key] = v;
  });
  return { draft: draft, errors: errors };
}

function submitForm(ev) {
  ev.preventDefault();
  const result = readForm();
  if (result.errors.length) {
    dom.formError.textContent = result.errors.join('；');
    dom.formError.hidden = false;
    report('warn', 'validation failed: ' + result.errors.join('; '));
    return;
  }
  if (state.editingId) {
    state.items = state.items.map(function (i) {
      return i.id === state.editingId ? normalize(Object.assign({}, i, result.draft, { id: i.id })) : i;
    });
    toast('已保存修改');
  } else {
    state.items.unshift(normalize(result.draft));
    toast('已新增' + SPEC.entityName);
  }
  persist();
  closeForm();
  render();
}

/* ------------------------------------------------------------------ boot */
if (embedded) {
  window.addEventListener('message', function (ev) {
    const msg = ev.data;
    if (!msg || msg.source !== 'forgeflow-host') return;
    if (msg.type === 'init') boot(msg.data);
  });
  try {
    window.parent.postMessage({ source: 'forgeflow-app', type: 'ready', key: STORAGE_KEY, appId: SPEC.appId }, '*');
  } catch (e) { /* ignore */ }
  setTimeout(function () { boot(null); }, 1500);
} else {
  boot(readStandalone());
}
`;
}
